# Royal Gift

Мини‑приложение‑подарок для поздравления:
* Ввод секретного кода `I'M A QUEEN`
* Салют, фанфары, конфетти
* Offline‑fallback и mobile‑friendly

Развертывание:
1. `git clone ...`
2. Залей на Vercel / Netlify / GitHub Pages (HTML-only).
